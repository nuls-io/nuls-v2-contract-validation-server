package com.cat.module;


import io.nuls.contract.sdk.Address;

import java.math.BigInteger;

/**
 * 游戏盒子
 */
public class Buyer {
    /**
     * 购买人
     */
    private Address sender;
    /**
     * 购买高度
     */
    private Long buyHeight;
    /**
     * 购买价格
     */
    private BigInteger buyPrice;

    /**
     * 购买的盒子编号
     */
    private Integer boxNo;
    /**
     * 开奖盒子编号
     */
    private Integer bonusBoxNo;
    /**
     * 购买名次
     * 第几个购买
     */
    private Integer soldNo;

    public Buyer(Address sender, Long buyHeight, Integer boxNo,
                 BigInteger buyPrice,Integer soldNo) {
        this.sender = sender;
        this.buyHeight = buyHeight;
        this.boxNo = boxNo;
        this.buyPrice = buyPrice;
        this.soldNo = soldNo;
    }

    public Address getSender() {
        return sender;
    }

    public void setSender(Address sender) {
        this.sender = sender;
    }

    public Long getBuyHeight() {
        return buyHeight;
    }

    public void setBuyHeight(Long buyHeight) {
        this.buyHeight = buyHeight;
    }

    public Integer getBoxNo() {
        return boxNo;
    }

    public void setBoxNo(Integer boxNo) {
        this.boxNo = boxNo;
    }

    public Integer getBonusBoxNo() {
        return bonusBoxNo;
    }

    public void setBonusBoxNo(Integer bonusBoxNo) {
        this.bonusBoxNo = bonusBoxNo;
    }

    public BigInteger getBuyPrice() {
        return buyPrice;
    }

    public void setBuyPrice(BigInteger buyPrice) {
        this.buyPrice = buyPrice;
    }

    public void setSoldNo(Integer soldNo) {
        this.soldNo = soldNo;
    }

    public Integer getSoldNo() {
        return soldNo;
    }
}
