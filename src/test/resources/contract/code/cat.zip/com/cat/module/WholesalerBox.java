package com.cat.module;

import io.nuls.contract.sdk.Address;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 批发商批发的盒子
 */
public class WholesalerBox {

    private Long id;
    /**
     * 批发商
     */
    private Address wholesaler;
    /**
     * 批发购买高度
     */
    private Long buyHeight;
    /**
     * 购买时间
     */
    private Long buyBlockTime;
    /**
     * 奖金盒子集合
     * key:盒子编号
     * value:盒子奖金，单位Na
     */
    private Map<Integer,BigInteger> bonusBoxes;

    /**
     * 雪球盒子编号
     * 在拆分奖金时，最低的奖金盒子为雪球盒子
     * 购买盒子中2成金额累加到雪球盒子上
     * 如果雪球盒子被抽走，则在当前奖金盒子中选一个最低的作为新的雪球盒子
     */
    private Integer snowballBox;

    /**
     * 已开盒子的真实编号
     */
    private HashSet<Integer> openBoxNos = new HashSet<Integer>();

    /**
     * 已开奖金盒子的真实编号
     */
    private HashSet<Integer> openBonusBoxNos = new HashSet<Integer>();

    /**
     * 买家集合，买家先购买再开奖
     * key：购买盒子编号
     * value：买家信息
     */
    private LinkedHashMap<Integer,Buyer> buyers = new LinkedHashMap<Integer,Buyer>();

    private HashMap<Integer,Integer> boxSoldNo = new HashMap<Integer,Integer>();

    /**
     * 已售盒子个数，用于计算玩家购买盒子的金额
     */
    private Integer soldCount = 0;

    /**
     * 盒子单价
     */
    private BigInteger unitPrice;

    /**
     * 盒子总量
     */
    private BigInteger boxesCount;

    /**
     * 玩家购买盒子，批发商的分成收益，单位Na
     * 该收益会在结束游戏的时候，根据nuls和pupu币的汇率进行换算将na兑换pupu给批发商
     */
    private BigInteger income = BigInteger.ZERO;
    /**
     * 未抽中奖金
     */
    private BigInteger noSoldBonus;
    /**
     * 游戏状态
     */
    private Integer status = GameStatus.SELLING;

    public WholesalerBox(Address sender, Long blockHeight) {
        this.wholesaler = sender;
        this.buyHeight = blockHeight;
    }

    /**
     * 获取构买盒子价格
     * 购买价格 = 盒子批发单价 + 盒子批发单价*0.2*N（第N个购买盒子）
     * @return
     */
    public BigInteger getBuyBoxPrice() {
        BigDecimal price = new BigDecimal(unitPrice);
        price = price.add(
                    price.multiply(new BigDecimal("0.2"))
                        .multiply(new BigDecimal(soldCount))
                ).setScale(0,BigDecimal.ROUND_HALF_UP);
        return price.toBigInteger();
    }

    public void soldOne() {
        soldCount++;
    }

    public HashSet<Integer> getOpenBoxNos() {
        return openBoxNos;
    }

    public void setOpenBoxNos(HashSet<Integer> openBoxNos) {
        this.openBoxNos = openBoxNos;
    }

    public Address getWholesaler() {
        return wholesaler;
    }

    public void setWholesaler(Address wholesaler) {
        this.wholesaler = wholesaler;
    }

    public Long getBuyHeight() {
        return buyHeight;
    }

    public void setBuyHeight(Long buyHeight) {
        this.buyHeight = buyHeight;
    }

    public Map<Integer, BigInteger> getBonusBoxes() {
        return bonusBoxes;
    }

    public void setBonusBoxes(Map<Integer, BigInteger> bonusBoxes) {
        this.bonusBoxes = bonusBoxes;
    }

    public Integer getSoldCount() {
        return soldCount;
    }

    public void setSoldCount(Integer soldCount) {
        this.soldCount = soldCount;
    }

    public LinkedHashMap<Integer, Buyer> getBuyers() {
        return buyers;
    }

    public void setBuyers(LinkedHashMap<Integer, Buyer> buyers) {
        this.buyers = buyers;
    }

    public BigInteger getIncome() {
        return income;
    }

    public void setIncome(BigInteger income) {
        this.income = income;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BigInteger getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigInteger unitPrice) {
        this.unitPrice = unitPrice;
    }

    public HashSet<Integer> getOpenBonusBoxNos() {
        return openBonusBoxNos;
    }

    public void setOpenBonusBoxNos(HashSet<Integer> openBonusBoxNos) {
        this.openBonusBoxNos = openBonusBoxNos;
    }

    public BigInteger getBoxesCount() {
        return boxesCount;
    }

    public void setBoxesCount(BigInteger boxesCount) {
        this.boxesCount = boxesCount;
    }

    public Integer getSnowballBox() {
        return snowballBox;
    }

    public void setSnowballBox(Integer snowballBox) {
        this.snowballBox = snowballBox;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public BigInteger getNoSoldBonus() {
        return noSoldBonus;
    }

    public void setNoSoldBonus(BigInteger noSoldBonus) {
        this.noSoldBonus = noSoldBonus;
    }

    public Long getBuyBlockTime() {
        return buyBlockTime;
    }

    public void setBuyBlockTime(Long buyBlockTime) {
        this.buyBlockTime = buyBlockTime;
    }

    public HashMap<Integer, Integer> getBoxSoldNo() {
        return boxSoldNo;
    }

    public void setBoxSoldNo(HashMap<Integer, Integer> boxSoldNo) {
        this.boxSoldNo = boxSoldNo;
    }
}
