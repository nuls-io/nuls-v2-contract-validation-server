package com.cat.contract;

import com.cat.module.Buyer;
import com.cat.module.GameStatus;
import com.cat.module.Random;
import com.cat.module.WholesalerBox;
import io.nuls.contract.sdk.*;
import io.nuls.contract.sdk.annotation.JSONSerializable;
import io.nuls.contract.sdk.annotation.Required;
import io.nuls.contract.sdk.annotation.View;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

/**
 * 薛定谔的猫游戏
 * 游戏机制：
 * 1.批发商批发盒子，总盒子不小于1个，单个盒子单价不小于1NULS。
 * 批发总价为盒子奖金，将奖金单边二分直至最低奖金不小于1NULS，且奖金个数不超过批发盒子总数
 * 所得的奖金随机分配到购买盒子中，这里的直接获取1~100的随机数。
 * 玩家购买的盒子编号和批发商的奖金编号没有关系，玩家购买后再进行开奖获取随机数计算所得盒子编号才是奖金盒子编号
 *
 * 2.玩家购买批发商的盒子，记录玩家购买盒子编号和购买块高度
 *
 * 3.盒子开奖
 * 在购买盒子后2个块高度，获取当前块往前10个块高度的随机种子加上购买的盒子编号生成随机数
 * 当随机数和奖金编号匹配，则合约将奖金NULS转给买家
 * 买家购买盒子的金额会分成3份：
 * 75%成分给批发商作为批发商的收益，实时返给批发商
 * 20%成用于奖励滚动，累到到滚动盒子：第一次会标记最小奖励盒子为滚动盒子，将2成金额累加到滚动盒子，如果滚动盒子被抽走
 * 则选出当时最小奖励为新的滚动盒子
 * 5% 作为游戏手续费游戏商家收益
 *
 * 4.结束游戏
 * 在批发商批发盒子后的8640块高度（一天24小时，出块间隙10s）
 * 结束一局盒子游戏，将未被抽中的NULS奖金返回给批发商
 *
 */
public class SchrodingerCatContract implements Contract {
    /**
     * 距离购买盒子后开盒子的块高度
     */
    private static final  Integer OPEN_BOX_BLOCK_COUNT = 2;

    /**
     * 开奖盒子的种子块个数
     */
    private static final  Integer OPEN_BOX_SEED_BLOCK_LENGTH = 10;

    /**
     * 距离批发商批发盒子后关闭所有盒子的快高度
     * 出块间隙10S，8440 = 一天
     */
    private static final  Integer  CLOSE_BOX_BLOCK_COUNT = 8440;

    /**
     * 批发商抽成购买盒子金额的75%
     * 兑换成pupu币返利给批发商
     */
    private static final BigDecimal SHARE_WHOLESALER = new BigDecimal("0.75");

    /**
     * 游戏商户抽成购买盒子金额的0.05%
     * 用于维护游戏的手续费
     */
    private static final BigDecimal SHARE_BANK = new BigDecimal("0.05");

    /**
     * 雪球盒子抽成购买盒子金额的20%
     * 用于滚利激励玩家抽奖
     */
    private static final BigDecimal SHARE_SNOWBALL = new BigDecimal("0.2");

    /**
     * 最小盒子单价 1NULS
     * 不接受小于此单价的盒子批发
     */
    private static final BigInteger MIN_UNIT_PRICE = BigInteger.valueOf(100000000L);

    /**
     * 最小可拆分的奖金金额2NULS
     */
    private static final BigInteger SPLIT_MIN_BONUS = BigInteger.valueOf(200000000L);

    /**
     * 游戏商户地址
     */
    private Address gamer;

    /**
     * token地址
     */
    private Address token;

    /**
     * 批发商盒子集合
     */
    Map<Long, WholesalerBox> wholesalerBoxList = new LinkedHashMap<Long,WholesalerBox>();

    public SchrodingerCatContract(@Required String gamerAddress, @Required String tokenAddress){
        this.gamer = new Address(gamerAddress);
        this.token = new Address(tokenAddress);
    }

    /**
     * 批发商批发盒子
     * 将批发商总购买金额，进行单边二分直到不小于1nuls，且拆分奖金个数不大于盒子总数。
     * 所得的奖金随机分配到购买盒子中，这里的直接获取1~100的随机数。
     * 玩家购买的盒子编号和批发商的奖金编号没有关系，玩家购买后再进行开奖获取随机数计算所得盒子编号才是奖金盒子编号
     * @param boxesCount 批发盒子数量
     *                   数量必须大于1小于400，且盒子单价不得小于1NULS。
     */
    public Long tokenBuyWholesaler(@Required String address,
                                   @Required BigInteger value,
                                   @Required Integer boxesCount) {
        Utils.require(token.equals(Msg.sender()),"ERROR");
        Utils.require(boxesCount != null && boxesCount > 0 && boxesCount <= 400,
                "WHOLESALER_BOX_COUNT_ERROR");
        BigInteger count = BigInteger.valueOf(boxesCount);
        BigInteger unitPrice = value.divide(count);

        Utils.require(unitPrice.compareTo(MIN_UNIT_PRICE) > -1,
                "UNIT_PRICE_ERROR");

        Long id = wholesalerBoxList.size() +1l;

        WholesalerBox wholesalerBox = new WholesalerBox(new Address(address),Block.newestBlockHeader().getHeight()+1);
        wholesalerBox.setId(id);
        wholesalerBox.setBoxesCount(count);
        wholesalerBox.setUnitPrice(unitPrice);
        wholesalerBox.setBuyBlockTime(Block.timestamp());
        splitBox(wholesalerBox,value);

        wholesalerBoxList.put(id, wholesalerBox);
        return id;
    }

    /**
     * 玩家购买批发商的盒子，记录玩家购买盒子编号和购买块高度
     * 购买价格 = 盒子批发单价 + 盒子批发单价*0.2*N（第N个购买盒子）
     * @param wholesalerBoxId 批发商盒子id
     * @param boxNo  盒子编号
     */
    public void tokenBuyBox(@Required String address, @Required BigInteger value,@Required Long wholesalerBoxId, @Required Integer boxNo) {
        Utils.require(token.equals(Msg.sender()),"ERROR");
        WholesalerBox wholesalerBox = wholesalerBoxList.get(wholesalerBoxId);
        Utils.require(wholesalerBox != null,"WHOLESALER_BOX_NOT_FOUND");
        //判断批发商盒子是否还能购买，可购买高度=批发高度+CLOSE_BOX_BLOCK_COUNT - OPEN_BOX_BLOCK_COUNT -1
        //防止结束游戏合盒子开奖冲突
        Utils.require(wholesalerBox.getStatus().equals(GameStatus.SELLING),"BOX_CLOSE");

        Long canBuyHeight = wholesalerBox.getBuyHeight()+CLOSE_BOX_BLOCK_COUNT-OPEN_BOX_BLOCK_COUNT-1;
        Utils.require(Block.newestBlockHeader().getHeight()+1 <= canBuyHeight,"BOX_CLOSE");

        //判断盒子是否已售
        Utils.require(wholesalerBox.getBuyers().get(boxNo) == null,"BOX_SOLD");
        //判断购买盒子金额是否正确
        BigInteger buyBoxPrice = wholesalerBox.getBuyBoxPrice();
        Utils.require(value.compareTo(buyBoxPrice) == 0, "PRICE_ERROR");

        Buyer buyer = new Buyer(new Address(address),Block.newestBlockHeader().getHeight()+1,boxNo,buyBoxPrice,wholesalerBox.getSoldCount());
        wholesalerBox.setSoldCount(wholesalerBox.getSoldCount()+1);
        wholesalerBox.getBuyers().put(boxNo,buyer);
        wholesalerBox.getBoxSoldNo().put(buyer.getSoldNo(),boxNo);
    }

    /**
     * 盒子开奖
     * 在购买盒子后2个块高度，获取当前块往前10个块高度的随机种子加上购买的盒子编号生成随机数
     * 当随机数和奖金编号匹配，则合约将奖金NULS转给买家
     * 买家购买盒子的金额会分成3份：
     * 5成分给批发商作为批发商的收益
     * 3成存入分红银行用于系统调用接口维护消耗和清算分红给银行存款用户
     * 2成用于奖励滚动，累到到滚动盒子：第一次会标记最小奖励盒子为滚动盒子，将2成金额累加到滚动盒子，如果滚动盒子被抽走
     * 则选出当时最小奖励为新的滚动盒子
     * @param wholesalerBoxId 批发商盒子id
     * @param boxNo  盒子编号
     */
    public BigInteger openBox(@Required Long wholesalerBoxId, @Required Integer boxNo) {
        WholesalerBox wholesalerBox = wholesalerBoxList.get(wholesalerBoxId);
        Utils.require(wholesalerBox != null,"WHOLESALER_BOX_NOT_FOUND");
        Utils.require(wholesalerBox.getStatus().equals(GameStatus.SELLING),"BOX_CLOSE");

        Utils.require(wholesalerBox.getBuyers().get(boxNo) != null,"BOX_UNSOLD");

        Buyer buyer = wholesalerBox.getBuyers().get(boxNo);

        Utils.require(buyer.getBonusBoxNo() == null, "BOX_OPENED");
        return openBox(wholesalerBox,buyer,true);
    }


    /**
     * 开奖
     * @param wholesalerBox
     * @param buyer
     * @param checkClose 判断是否需要关闭游戏
     * @return
     */
    private BigInteger openBox(WholesalerBox wholesalerBox,  Buyer buyer,Boolean checkClose) {
        if (buyer.getBonusBoxNo() != null) {
            return wholesalerBox.getBonusBoxes().get(buyer.getBonusBoxNo());
        }
        //判断开奖盒子之前的盒子是否开奖，没有则先开之前的盒子
        // 因为购买盒子成本递增，所有开启盒子顺序不能乱
        if (buyer.getSoldNo() > 0) {
            Buyer beforeBuyer = wholesalerBox.getBuyers().get(wholesalerBox.getBoxSoldNo().get(buyer.getSoldNo()-1));
            if (beforeBuyer.getBonusBoxNo() == null) {
                openBox(wholesalerBox, beforeBuyer, false);
            }
        }
        Integer openBoxNo = getOpenBoxNo(buyer.getBuyHeight(),buyer.getBoxNo(),
                wholesalerBox.getBoxesCount().intValue(),
                wholesalerBox.getOpenBoxNos());

        wholesalerBox.getOpenBoxNos().add(openBoxNo);
        buyer.setBonusBoxNo(openBoxNo);

        //拆分购买金额
        BigDecimal buyBoxPriceDecimal = new BigDecimal(buyer.getBuyPrice());
        //批发商返利
        BigInteger shareWholesaler = buyBoxPriceDecimal.multiply(SHARE_WHOLESALER).setScale(0,BigDecimal.ROUND_HALF_UP).toBigInteger();
        wholesalerBox.setIncome(wholesalerBox.getIncome().add(shareWholesaler));
        transfer(wholesalerBox.getWholesaler(),shareWholesaler);

        //如果开奖为最后一个盒子，则中奖盒子为雪球盒子
        if (wholesalerBox.getOpenBoxNos().size() == wholesalerBox.getBoxesCount().intValue()) {
            BigInteger snowballBonus = wholesalerBox.getBonusBoxes().get(openBoxNo);
            snowballBonus = snowballBonus.add(buyBoxPriceDecimal.multiply(SHARE_SNOWBALL).setScale(0,BigDecimal.ROUND_HALF_UP).toBigInteger());
            wholesalerBox.getBonusBoxes().put(openBoxNo,snowballBonus);
        }

        //如果中奖，合约将奖金转给玩家
        BigInteger bonus = wholesalerBox.getBonusBoxes().get(openBoxNo) ;
        if (bonus != null) {
            transfer(buyer.getSender(),bonus);
            wholesalerBox.getOpenBonusBoxNos().add(openBoxNo);
        } else {
            bonus = BigInteger.ZERO;
        }

        //雪球盒子不能为中奖盒子，从剩余奖金盒子或者非奖金盒子中挑选雪球盒子
        if (wholesalerBox.getOpenBoxNos().size() < wholesalerBox.getBoxesCount().intValue()){
            //累加雪球奖金
            Integer snowballBoxNo = getSnowballBoxNo(openBoxNo, wholesalerBox);
            BigInteger snowballBonus = wholesalerBox.getBonusBoxes().get(snowballBoxNo);
            snowballBonus = snowballBonus.add(buyBoxPriceDecimal.multiply(SHARE_SNOWBALL).setScale(0, BigDecimal.ROUND_HALF_UP).toBigInteger());
            wholesalerBox.getBonusBoxes().put(snowballBoxNo, snowballBonus);
        }

        //手续费
        BigInteger feeBonus = buyBoxPriceDecimal.multiply(SHARE_BANK).setScale(0,BigDecimal.ROUND_HALF_UP).toBigInteger();
        transfer(gamer,feeBonus);

        //如果是最后一个盒子则关闭游戏
        if (checkClose && wholesalerBox.getOpenBoxNos().size() == wholesalerBox.getBoxesCount().intValue()) {
            closeBoxGame(wholesalerBox.getId());
        }
        return bonus;
    }

    /**
     * 结束一盘盒子游戏
     * 在批发商批发盒子后的8640块高度（一天24小时，出块间隙10s）结束一局盒子游戏，将未被抽中的NULS奖金返回给批发商
     * 通过汇率将批发收益的Nuls换成pupu币转给批发商
     * 将批发商收益Nuls转给游戏商家
     * @param wholesalerBoxId 批发商盒子id
     */
    public void closeBoxGame(@Required Long wholesalerBoxId) {
        Utils.require(gamer.equals(Msg.sender()),"ERROR");
        WholesalerBox wholesalerBox = wholesalerBoxList.get(wholesalerBoxId);
        Utils.require(wholesalerBox != null,"WHOLESALER_BOX_NOT_FOUND");
        Utils.require(wholesalerBox.getStatus().equals(GameStatus.SELLING),"BOX_CLOSED");
        Utils.require(wholesalerBox.getBuyHeight()+CLOSE_BOX_BLOCK_COUNT <= Block.newestBlockHeader().getHeight()+1,"BOX_CANT_CLOSE");
        //检查是否有已经购买的盒子，未开奖，优先将这些盒子依次开奖
        for (Buyer buyer : wholesalerBox.getBuyers().values()) {
            if (buyer.getBonusBoxNo() == null ){
                openBox(wholesalerBox, buyer,false);
            }
        }

        //检查未被抽中的奖金，合约转账给批发商
        BigInteger noSoldBonus = BigInteger.ZERO;
        for (Integer boxNo : wholesalerBox.getBonusBoxes().keySet()) {
            if (!wholesalerBox.getOpenBoxNos().contains(boxNo)) {
                noSoldBonus = noSoldBonus.add(wholesalerBox.getBonusBoxes().get(boxNo));
            }
        }
        if (noSoldBonus.compareTo(BigInteger.ZERO) > 0) {
            transfer(wholesalerBox.getWholesaler(),noSoldBonus);
        }
        wholesalerBox.setNoSoldBonus(noSoldBonus);
        wholesalerBox.setStatus(GameStatus.DONE);
    }

    /**
     * 转账，分为转代币和转NULS
     * @param to
     * @param amount
     */
    private void transfer(Address to, BigInteger amount) {
        String[][] args = new String[2][];
        args[0] = new String[]{to.toString()};
        args[1] = new String[]{amount.toString()};
        token.call("transfer",null,args,null);
    }

    /**
     * 获取雪球盒子编号
     * 如果中奖盒子不是雪球盒子，则返回雪球盒子编号
     * 如果玩家中奖为雪球盒子，从未抽中的奖金盒子中选择最低奖金作为新的雪球盒子
     * @param openBoxNo 抽中盒子编号
     * @param wholesalerBox 批发商的盒子哟
     * @return
     */
    private static Integer getSnowballBoxNo(Integer openBoxNo, WholesalerBox wholesalerBox) {
        Integer snowballBoxNo = wholesalerBox.getSnowballBox();
        if (!openBoxNo.equals(snowballBoxNo)) {
            return snowballBoxNo;
        }

        //如果奖金盒子已经开完，则生成新的雪球盒子
        if (wholesalerBox.getOpenBonusBoxNos().size() == wholesalerBox.getBonusBoxes().keySet().size()) {
            return initNewSnowballBoxNo(wholesalerBox);
        }
        BigInteger minBonus = null;
        for (Integer boxNo: wholesalerBox.getBonusBoxes().keySet()){
            if (!wholesalerBox.getOpenBonusBoxNos().contains(boxNo)) {
                if (minBonus == null) {
                    minBonus = wholesalerBox.getBonusBoxes().get(boxNo);
                    snowballBoxNo = boxNo;
                } else if (minBonus.compareTo(wholesalerBox.getBonusBoxes().get(boxNo)) > 0) {
                    minBonus = wholesalerBox.getBonusBoxes().get(boxNo);
                    snowballBoxNo = boxNo;
                }
            }
        }
        wholesalerBox.setSnowballBox(snowballBoxNo);
        return snowballBoxNo;
    }

    /**
     * 从未开盒子中选一个盒子编号作为新的雪球盒子
     * @param wholesalerBox
     */
    private static Integer initNewSnowballBoxNo(WholesalerBox wholesalerBox) {
        BigInteger seed = Utils.getRandomSeed(Block.newestBlockHeader().getHeight()+1, 1);
        Integer snowballBoxNo = new Random(seed.longValue()).nextInt(wholesalerBox.getBoxesCount().intValue());
        boolean up = true;
        boolean down = true;
        Integer i = 1;
        while (wholesalerBox.getOpenBoxNos().contains(snowballBoxNo)) {
            if (snowballBoxNo == 100) {
                up = false;
                snowballBoxNo -= i-1;
            }
            if (snowballBoxNo == 1) {
                down = false;
                snowballBoxNo += i-1;
            }
            if (up && down) {
                if (i%2 == 1 ) {
                    snowballBoxNo = snowballBoxNo -i;
                }
                if (i%2 == 0) {
                    snowballBoxNo = snowballBoxNo + i;
                }
                i++;
            } else if (up) {
                snowballBoxNo = snowballBoxNo + 1;
            } else if (down){
                snowballBoxNo = snowballBoxNo -1;
            } else {
                break;
            }
        }
        wholesalerBox.setSnowballBox(snowballBoxNo);
        return snowballBoxNo;
    }

    /**
     * 获取开奖随机盒子No
     * 购买高度+OPEN_BOX_BLOCK_COUNT的截止高度和原始种子OPEN_BOX_SEED_BLOCK_LENGTH个数的种子合并用`SHA3-256`hash算法生成一个随机种子
     * 生成的种子加上购买的盒子编号作为 最终的种子
     * 通过种子获取批发盒子总数下的随机数，如果随机数对应的盒子已经被开走，则以该随机数为起点依次左右找临近未被开启的盒子
     * @param buyBlockHeight 购买盒子高度
     * @param buyBoxNo 购买盒子编号
     * @param boxesCount 批发盒子总数
     * @param openBoxNos 已经开奖盒子编号
     * @return
     */
    private static Integer getOpenBoxNo(Long buyBlockHeight,
                                        Integer buyBoxNo,
                                        Integer boxesCount,
                                        HashSet<Integer> openBoxNos) {
        //判断开奖高度是否正确
        Long openBlockHeight = buyBlockHeight + OPEN_BOX_BLOCK_COUNT;
        Utils.require(openBlockHeight <= Block.newestBlockHeader().getHeight()+1, "NOT_HEIGHT_OPEN");

        BigInteger seed = Utils.getRandomSeed(openBlockHeight, OPEN_BOX_SEED_BLOCK_LENGTH);
        seed = seed.add(BigInteger.valueOf(buyBoxNo));
        Random r = new Random(seed.longValue());
        Integer openBoxNo = r.nextInt(boxesCount)+1;

        boolean up = true;
        boolean down = true;
        Integer i = 1;
        while (openBoxNos.contains(openBoxNo)) {
            if (openBoxNo == 100) {
                up = false;
                openBoxNo -= i-1;
            }
            if (openBoxNo == 1) {
                down = false;
                openBoxNo += i-1;
            }
            if (up && down) {
                if (i%2 == 1 ) {
                    openBoxNo = openBoxNo -i;
                }
                if (i%2 == 0) {
                    openBoxNo = openBoxNo + i;
                }
                i++;
            } else if (up) {
                openBoxNo = openBoxNo + 1;
            } else if (down){
                openBoxNo = openBoxNo -1;
            } else {
                break;
            }
        }
        return openBoxNo;

    }

    /**
     * 拆分奖金
     * 单边二分直到不小于1nuls，且奖金个数不超过总盒子数
     * 随机生成奖励盒子的编号
     * @param totalBonus 总奖金，单位na
     */
    private static void splitBox(WholesalerBox wholesalerBox,BigInteger totalBonus) {
        Random r = new Random(Utils.getRandomSeed(Block.newestBlockHeader().getHeight()+1,5).longValue());
        Integer count = wholesalerBox.getBoxesCount().intValue();
        Map<Integer, BigInteger> bonusBox = new HashMap<Integer,BigInteger>();
        wholesalerBox.setBonusBoxes(bonusBox);
        HashSet<Integer> boxNos = new HashSet<Integer>();
        if (totalBonus.min(SPLIT_MIN_BONUS).equals(totalBonus)) {
            bonusBox.put(1,totalBonus);
            wholesalerBox.setSnowballBox(1);
            return ;
        }
        BigDecimal total = new BigDecimal(totalBonus);
        BigDecimal divider = new BigDecimal("2");
        BigDecimal min = new BigDecimal(MIN_UNIT_PRICE);
        Integer boxNo = null;
        while (true) {
            boxNo = getRandomBoxNo(count,boxNos,r);
            if (boxNos.size() == count) {
                bonusBox.put(boxNo,total.toBigInteger());
                break;
            }
            BigDecimal bonus = total.divide(divider,0,BigDecimal.ROUND_HALF_UP);
            if (bonus.compareTo(min) < 0 || total.subtract(bonus).compareTo(min)< 0) {
                bonusBox.put(boxNo,total.toBigInteger());
                break;
            }
            total = total.subtract(bonus);
            bonusBox.put(boxNo,bonus.toBigInteger());
        }
        wholesalerBox.setSnowballBox(boxNo);
    }

    /**
     * 获取盒子随机编号
     * @param nos
     * @return
     */
    private static Integer getRandomBoxNo(Integer count, HashSet<Integer> nos, Random r) {
        Integer no = r.nextInt(count)+1;
        Integer i = 0;
        while (nos.contains(no) && i < count) {
            no = r.nextInt(count)+1;
            i++;
        }
        //防止出现随机数一直取不正确,无限循环
        if (nos.contains(no) && i == count) {
            for (int j = 1;j <= count;j++) {
                if (!nos.contains(j)) {
                    no = j;
                    break;
                }
            }
        }
        nos.add(no);
        return no;
    }

    @View
    @JSONSerializable
    public WholesalerBox getWholesalerBox(@Required Long wholesalerBoxId) {
        return wholesalerBoxList.get(wholesalerBoxId);
    }

    @View
    public Map<String,Object> getBlockHeight(@Required Long wholesalerBoxId) {
        WholesalerBox wholesalerBox = wholesalerBoxList.get(wholesalerBoxId);
        Map<String,Object> result = new HashMap<String,Object>();
        result.put("block",Block.newestBlockHeader().getHeight()+1);
        Long canBuyHeight = wholesalerBox.getBuyHeight()+CLOSE_BOX_BLOCK_COUNT-OPEN_BOX_BLOCK_COUNT-1;
        result.put("canBuyHeight",canBuyHeight);
        result.put("flag",Block.newestBlockHeader().getHeight()+1 <= canBuyHeight);
        return result;
    }

    @View
    public BigInteger getBuyPrice(@Required Long wholesalerBoxId) {
        WholesalerBox wholesalerBox = wholesalerBoxList.get(wholesalerBoxId);
        Utils.require(wholesalerBox != null,"WHOLESALER_BOX_NOT_FOUND");
        return wholesalerBox.getBuyBoxPrice();
    }

    @View
    public List<BigInteger> getSoldBonus(@Required Long wholesalerBoxId) {
        WholesalerBox wholesalerBox = wholesalerBoxList.get(wholesalerBoxId);
        Utils.require(wholesalerBox != null,"WHOLESALER_BOX_NOT_FOUND");
        List<BigInteger> bonus = new ArrayList<BigInteger>();
        for (Integer no : wholesalerBox.getOpenBonusBoxNos()) {
            bonus.add(wholesalerBox.getBonusBoxes().get(no));
        }
        return bonus;
    }

    @View
    public List<BigInteger> getForSaleBonus(@Required Long wholesalerBoxId) {
        WholesalerBox wholesalerBox = wholesalerBoxList.get(wholesalerBoxId);
        Utils.require(wholesalerBox != null,"WHOLESALER_BOX_NOT_FOUND");
        List<BigInteger> bonus = new ArrayList<BigInteger>();
        for (Integer no : wholesalerBox.getBonusBoxes().keySet()) {
            if (!wholesalerBox.getOpenBonusBoxNos().contains(no)) {
                bonus.add(wholesalerBox.getBonusBoxes().get(no));
            }
        }
        return bonus;
    }

    @View
    public BigInteger getBoxBonus(@Required Long wholesalerBoxId, @Required Integer boxNo) {
        WholesalerBox wholesalerBox = wholesalerBoxList.get(wholesalerBoxId);
        Utils.require(wholesalerBox != null,"WHOLESALER_BOX_NOT_FOUND");
        Buyer buyer = wholesalerBox.getBuyers().get(boxNo);
        Utils.require(buyer != null && buyer.getBonusBoxNo() != null , "BOX_UNSOLD");
        BigInteger bonus = wholesalerBox.getBonusBoxes().get(buyer.getBonusBoxNo());
        return bonus == null ? BigInteger.ZERO : bonus;
    }
}
