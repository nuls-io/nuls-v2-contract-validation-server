package com.cat.module;

public class Random {
    private Long seed;
    private static final long multiplier = 0x5DEECE66DL;
    private static final long addend = 0xBL;
    private static final long mask = (1L << 48) - 1;

    public int nextInt(int bound) {
        int r = next(31);
        int m = bound - 1;
        if ((bound & m) == 0)  // i.e., bound is a power of 2
            r = (int)((bound * (long)r) >> 31);
        else {
            for (int u = r;
                 u - (r = u % bound) + m < 0;
                 u = next(31))
                ;
        }
        return r;
    }

    protected int next(int bits) {
        long oldseed, nextseed;
        nextseed = this.seed;
        do {
            oldseed = nextseed;
            nextseed = (oldseed * multiplier + addend) & mask;
        } while (nextseed == oldseed);
        this.seed = nextseed;
        return (int)(nextseed >>> (48 - bits));
    }

    public Random(long seed) {
        this.seed = (seed ^ multiplier) & mask;
    }

}
