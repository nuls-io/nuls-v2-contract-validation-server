package com.cat.module;

public final class GameStatus {

    /**
     * 盒子售卖中
     */
    public static final Integer SELLING = 1;

    /**
     * 已结束
     */
    public static final Integer DONE = 2;


}
