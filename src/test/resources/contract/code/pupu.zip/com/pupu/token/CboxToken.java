package com.pupu.token;

import io.nuls.contract.sdk.Address;
import io.nuls.contract.sdk.Contract;
import io.nuls.contract.sdk.Msg;
import io.nuls.contract.sdk.Utils;
import io.nuls.contract.sdk.annotation.Required;
import io.nuls.contract.sdk.annotation.View;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static io.nuls.contract.sdk.Utils.emit;
import static io.nuls.contract.sdk.Utils.require;

public class CboxToken implements Contract, Token {

    private final String name;
    private final String symbol;
    private final int decimals;
    private final String crateAddress;
    private BigInteger totalSupply = BigInteger.ZERO;

    private List<String> gameContract = new ArrayList<String>();
    private Map<Address, BigInteger> balances = new HashMap<Address, BigInteger>();
    private Map<Address, Map<Address, BigInteger>> allowed = new HashMap<Address, Map<Address, BigInteger>>();

    @Override
    @View
    public String name() {
        return name;
    }

    @Override
    @View
    public String symbol() {
        return symbol;
    }

    @Override
    @View
    public int decimals() {
        return decimals;
    }

    @Override
    @View
    public BigInteger totalSupply() {
        return totalSupply;
    }

    public CboxToken(@Required String name, @Required String symbol, @Required BigInteger initialAmount, @Required int decimals) {
        this.name = name;
        this.symbol = symbol;
        this.decimals = decimals;
        this.crateAddress = Msg.sender().toString();
        totalSupply = initialAmount.multiply(BigInteger.TEN.pow(decimals));;
        balances.put(Msg.sender(), totalSupply);
        emit(new TransferEvent(null, Msg.sender(), totalSupply));
    }

    @Override
    @View
    public BigInteger allowance(@Required Address owner, @Required Address spender) {
        Map<Address, BigInteger> ownerAllowed = allowed.get(owner);
        if (ownerAllowed == null) {
            return BigInteger.ZERO;
        }
        BigInteger value = ownerAllowed.get(spender);
        if (value == null) {
            value = BigInteger.ZERO;
        }
        return value;
    }

    @Override
    public boolean transferFrom(@Required Address from, @Required Address to, @Required BigInteger value) {
        subtractAllowed(from, Msg.sender(), value);
        subtractBalance(from, value);
        addBalance(to, value);
        emit(new TransferEvent(from, to, value));
        return true;
    }

    @Override
    @View
    public BigInteger balanceOf(@Required Address owner) {
        require(owner != null);
        BigInteger balance = balances.get(owner);
        if (balance == null) {
            balance = BigInteger.ZERO;
        }
        return balance;
    }

    @Override
    public boolean transfer(@Required Address to, @Required BigInteger value) {
        subtractBalance(Msg.sender(), value);
        addBalance(to, value);
        emit(new TransferEvent(Msg.sender(), to, value));
        return true;
    }

    @Override
    public boolean approve(@Required Address spender, @Required BigInteger value) {
        setAllowed(Msg.sender(), spender, value);
        emit(new ApprovalEvent(Msg.sender(), spender, value));
        return true;
    }

    /**
     * 添加游戏合约地址
     * @param address
     * @return
     */
    public boolean addGameContract(@Required String address) {
        Utils.require(crateAddress.equals(Msg.sender().toString()),"no power");
        if (!gameContract.contains(address)) {
            gameContract.add(address);
        }
        return true;
    }

    /**
     * 删除游戏合约
     * @param address
     * @return
     */
    public boolean removeGameContract(@Required String address) {
        Utils.require(crateAddress.equals(Msg.sender().toString()),"no power");
        if (gameContract.contains(address)) {
            gameContract.remove(address);
        }
        return true;
    }


    /**
     * 批发盒子
     * @param address 游戏合约地址
     * @param value 批发盒子总CBOX金额
     * @param boxCount 批发盒子总数
     * @param value 支付金额
     * @return
     */
    public Long buyWholesaler(@Required String address, @Required Integer boxCount,@Required BigInteger value) {
        Utils.require(gameContract.contains(address),"no gameContract");
        Address gameAddress = new Address(address);
        transfer(gameAddress,value);
        String[][] args = new String[3][];
        args[0] = new String[]{Msg.sender().toString()};
        args[1] = new String[]{value.toString()};
        args[2] = new String[]{boxCount.toString()};
        String wholesalerId = gameAddress.callWithReturnValue("tokenBuyWholesaler",null,args,null);
        return Long.parseLong(wholesalerId);
    }

    /**
     * 买盒子
     * @param address
     * @param wholesalerBoxId
     * @param boxNo
     * @param value
     * @return
     */
    public boolean buyBox(@Required String address, @Required Long wholesalerBoxId, @Required Integer boxNo,@Required BigInteger value) {
        Utils.require(gameContract.contains(address),"no gameContract");
        Address gameAddress = new Address(address);
        transfer(gameAddress,value);
        String[][] args = new String[4][];
        args[0] = new String[]{Msg.sender().toString()};
        args[1] = new String[]{value.toString()};
        args[2] = new String[]{wholesalerBoxId.toString()};
        args[3] = new String[]{boxNo.toString()};
        gameAddress.call("tokenBuyBox",null,args,null);
        return true;
    }

    public boolean increaseApproval(@Required Address spender, @Required BigInteger addedValue) {
        addAllowed(Msg.sender(), spender, addedValue);
        emit(new ApprovalEvent(Msg.sender(), spender, allowance(Msg.sender(), spender)));
        return true;
    }

    public boolean decreaseApproval(@Required Address spender, @Required BigInteger subtractedValue) {
        check(subtractedValue);
        BigInteger oldValue = allowance(Msg.sender(), spender);
        if (subtractedValue.compareTo(oldValue) > 0) {
            setAllowed(Msg.sender(), spender, BigInteger.ZERO);
        } else {
            subtractAllowed(Msg.sender(), spender, subtractedValue);
        }
        emit(new ApprovalEvent(Msg.sender(), spender, allowance(Msg.sender(), spender)));
        return true;
    }

    private void addAllowed(Address address1, Address address2, BigInteger value) {
        BigInteger allowance = allowance(address1, address2);
        check(allowance);
        check(value);
        setAllowed(address1, address2, allowance.add(value));
    }

    private void subtractAllowed(Address address1, Address address2, BigInteger value) {
        BigInteger allowance = allowance(address1, address2);
        check(allowance, value, "Insufficient approved token");
        setAllowed(address1, address2, allowance.subtract(value));
    }

    private void setAllowed(Address address1, Address address2, BigInteger value) {
        check(value);
        Map<Address, BigInteger> address1Allowed = allowed.get(address1);
        if (address1Allowed == null) {
            address1Allowed = new HashMap<Address, BigInteger>();
            allowed.put(address1, address1Allowed);
        }
        address1Allowed.put(address2, value);
    }

    private void addBalance(Address address, BigInteger value) {
        BigInteger balance = balanceOf(address);
        check(value, "The value must be greater than or equal to 0.");
        check(balance);
        balances.put(address, balance.add(value));
    }

    private void subtractBalance(Address address, BigInteger value) {
        BigInteger balance = balanceOf(address);
        check(balance, value, "Insufficient balance of token.");
        balances.put(address, balance.subtract(value));
    }

    private void check(BigInteger value) {
        require(value != null && value.compareTo(BigInteger.ZERO) >= 0);
    }

    private void check(BigInteger value1, BigInteger value2) {
        check(value1);
        check(value2);
        require(value1.compareTo(value2) >= 0);
    }

    private void check(BigInteger value, String msg) {
        require(value != null && value.compareTo(BigInteger.ZERO) >= 0, msg);
    }

    private void check(BigInteger value1, BigInteger value2, String msg) {
        check(value1);
        check(value2);
        require(value1.compareTo(value2) >= 0, msg);
    }



}
